"""
EJERCICIO 3 — Promedio de Valores Numéricos
############################################

Definí una función llamada `calcular_promedio_numerico(lista)` que reciba una
lista cualquiera y devuelva el **promedio** de los elementos que sean
numéricos (`int` o `float`).

- Los elementos no numéricos (strings, booleanos, listas, etc.) deben
  **ignorarse**.
- Si la lista no contiene ningún número, la función debe devolver `0`.

Ejemplos:

    calcular_promedio_numerico([10, 20, "hola", 30])    # 20.0
    calcular_promedio_numerico([1.5, 2.5, "x", 4])      # 2.6666...
    calcular_promedio_numerico(["a", "b", True, None])  # 0
    calcular_promedio_numerico([])                      # 0

Ayuda: usá `isinstance(elemento, (int, float))` para chequear si un elemento
es numérico. Tené en cuenta que `bool` es subclase de `int` en Python: si no
querés contar `True/False`, excluí explícitamente con
`not isinstance(elemento, bool)`.

"""
